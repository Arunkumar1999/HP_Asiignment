To run all the above programs on command prompt:

g++ <filename> -lpthread
./a.out

