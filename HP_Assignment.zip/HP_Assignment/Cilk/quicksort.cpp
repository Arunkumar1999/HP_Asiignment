#include <bits/stdc++.h>
#include<cilk/cilk.h>
#include<iostream>
#include<stdlib.h>
#include <chrono>
using namespace std::chrono;
using namespace std;



int partition(int A[], int left, int right)
{
	int p = A[right],i;
	int index = left - 1;
	int temp = 0;
	for (i = left; i < right ; i++)
	{
		if (A[i] < p)
		{
			temp  = A[index+1];
			A[index+1] = A[i];
			A[i] = temp;
			index += 1;
		}
	}
	index+=1;
	temp  = A[index];
	A[index] = A[right];
	A[right] = temp;
	return index;
}


void quick_sort(int A[], int left, int right)
{
	if (left < right)
	{
		int middle = partition(A, left, right);
		cilk_spawn quick_sort(A, left,middle - 1);
		quick_sort(A, middle + 1, right);
		cilk_sync;
	}
}

int main()
{
	int size;
	size=128;
	
	int A[size] ;
	for(int i = 0; i<size; i++)
		A[i] = (rand() % (size*5)) + 1;
	quick_sort(A, 0, size - 1);
	for(int i = 0; i < size; i++)
		cout << A[i] << " ";
	cout << endl;
	return 0;
}
