#include<cilk/cilk.h>
#include<iostream>
#include<stdlib.h>
#include <chrono>
using namespace std::chrono;
using namespace std;



int main()
{
	int size = 128;
	for(int s=0; s<12;s++)
	{
			size = size*2;
			//cout<< "size : "<< size << endl;
			int A[size] , B[size] , C[size];
			for(int i=0;i<size;i++)
			{
				A[i] = (rand() % size) + 1;
				B[i] = (rand() % size) + 1;
			}

			 auto start = high_resolution_clock::now();
			 for(int i=0;i<size;i++)
	 			C[i] = A[i] + B[i];
			 auto stop = high_resolution_clock::now();
			 auto difference = duration_cast<microseconds>(stop - start);
			 cout << "time taken by sequential : " << difference.count() << endl;

			 start = high_resolution_clock::now();
	 			C[:] = A[:] + B[:];
		 	 stop = high_resolution_clock::now();
			 difference = duration_cast<microseconds>(stop - start);
			 cout << "array notation time taken : " << difference.count() << endl;
		}
	return 0;
}
