To run all the above progrms:

gcc <filename> -openmp
./a.out