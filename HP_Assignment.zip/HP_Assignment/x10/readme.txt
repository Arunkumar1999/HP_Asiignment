to run the code

mpirun -np <number of place> <filename>
