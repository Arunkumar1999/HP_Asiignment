#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<time.h>

void *matrix_mult(void *matrix)
{
	int *data=(int *)matrix;
	int k=0,i=0;
	int u=data[0];
	for (i=0;i<=u;i++)
		k+=data[i]*data[i+u];
	int *p=malloc(sizeof(int));
	*p=k;
	pthread_exit(p);
}

int main()
{
	int row_1=6,row_2=6,col_1=6,col_2=6,i,j,k;

	int a[row_1][col_1];
	int b[row_2][col_2];
	printf("MATRIX A\n");
	srand(time(0)); 
	for(int i=0;i<row_1;i++)
	{
		for (int j=0;j<col_1;j++)
		{
			a[i][j]=rand()%10;
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	printf("MATRIX B\n");
	
	for(int i=0;i<row_2;i++)
	{
		for (int j=0;j<col_2;j++)
		{
			b[i][j]=rand()%10;
			printf("%d ",b[i][j]);
		}
		printf("\n");
	}

	int number_of_threads=row_1*col_2;
	pthread_t *threads=malloc(number_of_threads*(sizeof(pthread_t)));
	int *data,count=0;
	printf("RESULT\n");
	for (i = 0; i < row_1; i++) 
		for (j = 0; j < col_2; j++) 
		{ 
		 
			 
			data = (int *)malloc((col_1+row_2+1)*sizeof(int)); 
			data[0] = col_1; 

			for (k = 0; k < col_1; k++) 
			data[k+1] = a[i][k]; 

			for (k = 0; k < row_2; k++) 
			data[k+col_1+1] = b[k][j]; 

			 
			pthread_create(&threads[count++], NULL,  
			               matrix_mult, (void*)(data)); 
		  
		    } 
	for (i = 0; i < number_of_threads; i++)  
	{ 
		void *k; 

		pthread_join(threads[i], &k); 


		int *p = (int *)k; 
		printf("%d ",*p); 
		if ((i + 1) % col_2 == 0) 
			printf("\n"); 
	} 



	return 0; 

}