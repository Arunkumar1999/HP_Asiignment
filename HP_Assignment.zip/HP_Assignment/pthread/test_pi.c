#include <stdio.h>
#include <math.h>
#include <stdlib.h> 
#include <pthread.h>
#define NUM_RECT 20000000
#define NUMTHREADS 12
double total_pi = 0.0; 
pthread_mutex_t take_lock;

void *Area(void *data){
   int my_num = *((int *)data);
   double h = 2.0 / NUM_RECT;
   double partial_sum = 0.0, x;

   for (int i = my_num; i < NUM_RECT; i += NUMTHREADS){
            x = -1 + (i + 0.5f) * h;
           partial_sum += (sqrt(1.0 - x*x)) * h;
   }
   pthread_mutex_lock(&take_lock);
   total_pi += partial_sum; 
   pthread_mutex_unlock(&take_lock);
   return 0;
}

int main(int argc, char **argv) {

pthread_t thread_handle[NUMTHREADS]; int thread_id[NUMTHREADS], i;
pthread_mutex_init(&take_lock, NULL);
for ( i = 0; i < NUMTHREADS; ++i ) {
  thread_id[i] = i;
  pthread_create(&thread_handle[i],NULL,Area,(void*)&thread_id[i]);        
}
for ( i = 0; i < NUMTHREADS; ++i ) {
   pthread_join(thread_handle[i], NULL);
}
total_pi *= 2.0;
printf("pi: %12.9f\n", total_pi );
pthread_mutex_destroy(&take_lock);
return 0;
}