cmd to run

gcc <filename> -lpthread -lm

./a.out