command to run 

g++ <filename> -ltbb -o <anyname>
./<anyname>