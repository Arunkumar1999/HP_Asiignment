#include<iostream.h>
#include <tbb/parallel_for.h>
#include <tbb/blocked_range.h>

using namespace tbb;

const int size = 1000;

float a[size*size];
float b[size*size];
float c[size*size];


class ADD
{
public:
    void operator()(blocked_range<int> r) const {
        for (int i = r.begin(); i != r.end(); ++i) {
            
                    c[i] = a[i] + b[i];
                }
            }
        
};


int main()
{
    for (int i = 0; i < size*size; ++i) {
        
            a[i] = (float)i + j;
            b[i] = (float)i - j;
            c[i] = 0.0f;
        
    }
     cout << "MATRIX A"<<endl;
    for (int i = 0; i < size*size; ++i) {
            cout<<a[i]<<" ";
            if((i+1)%size==0)
            {
                cout << endl; 
            }
     }    
     cout << "MATRIX B"<<endl;
     for (int i = 0; i < size*size; ++i) {
            cout<<b[i]<<" ";
            if((i+1)%size==0)
            {
                cout << endl; 
            }
     }    
    parallel_for(blocked_range<int>(0,size*size), ADD());
    cout<<"Result after addition:"
    for (int i = 0; i < size*size; ++i) {
            cout<<c[i]<<" ";
            if((i+1)%size==0)
            {
                cout << endl; 
            }
     }    
    return 0;
}