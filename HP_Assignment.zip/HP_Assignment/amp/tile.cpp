#include<iostream>
#include<stdlib.h>
#include <ctime>
#include <chrono>
using namespace std;
#include <amp.h>
using namespace concurrency;

void fun_for_8() {
    static const int sz=64;
    static const int size_of_tile = 8;

    int A[sz * sz], B[sz * sz], C[sz * sz];

    for (int i = 0; i < sz * sz; i++)
    {
        A[i] = (rand() % (sz * 2)) + 1;
        B[i] = (rand() % (sz * 2)) + 1;
        C[i] = 0;
    }


    array_view<int, 2> arrayA(sz, sz, A);
    array_view<int, 2> arrayB(sz, sz, B);
    array_view<int, 2> arrayC(sz, sz, C);


    parallel_for_each(arrayC.extent.tile<size_of_tile, size_of_tile>(),
        [=](tiled_index<size_of_tile, size_of_tile> thid) restrict(amp)
    {
        int ti = thid.local[0];
        int tj = thid.local[1];

        for (int i = 0; i < sz; i += size_of_tile) {
            tile_static int Aarray[size_of_tile][size_of_tile];
            tile_static int Barray[size_of_tile][size_of_tile];
            Aarray[ti][tj] = arrayA(thid.global[0], tj + i);
            Barray[ti][tj] = arrayB(ti + i, thid.global[1]);
            thid.barrier.wait();

            for (int k = 0; k < size_of_tile; k++) {
                arrayC(thid.global[0], thid.global[1]) += Aarray[ti][k] * Barray[k][tj];
            }

            thid.barrier.wait();
        }

    });

    arrayC.synchronize();
}

void fun_for_16() {
    static const int sz=64;
    static const int size_of_tile = 16;

    int A[sz * sz], B[sz * sz], C[sz * sz];

    for (int i = 0; i < sz * sz; i++)
    {
        A[i] = (rand() % (sz * 2)) + 1;
        B[i] = (rand() % (sz * 2)) + 1;
        C[i] = 0;
    }


    array_view<int, 2> arrayA(sz, sz, A);
    array_view<int, 2> arrayB(sz, sz, B);
    array_view<int, 2> arrayC(sz, sz, C);


    parallel_for_each(arrayC.extent.tile<size_of_tile, size_of_tile>(),
        [=](tiled_index<size_of_tile, size_of_tile> thid) restrict(amp)
    {
        int ti = thid.local[0];
        int tj = thid.local[1];

        for (int i = 0; i < sz; i += size_of_tile) {
            tile_static int Aarray[size_of_tile][size_of_tile];
            tile_static int Barray[size_of_tile][size_of_tile];
            Aarray[ti][tj] = arrayA(thid.global[0], tj + i);
            Barray[ti][tj] = arrayB(ti + i, thid.global[1]);
            thid.barrier.wait();

            for (int k = 0; k < size_of_tile; k++) {
                arrayC(thid.global[0], thid.global[1]) += Aarray[ti][k] * Barray[k][tj];
            }

            thid.barrier.wait();
        }

    });

    arrayC.synchronize();
}

void fun_for_32() {
    static const int sz=64;
    static const int size_of_tile = 32;

    int A[sz * sz], B[sz * sz], C[sz * sz];

    for (int i = 0; i < sz * sz; i++)
    {
        A[i] = (rand() % (sz * 2)) + 1;
        B[i] = (rand() % (sz * 2)) + 1;
        C[i] = 0;
    }


    array_view<int, 2> arrayA(sz, sz, A);
    array_view<int, 2> arrayB(sz, sz, B);
    array_view<int, 2> arrayC(sz, sz, C);


    parallel_for_each(arrayC.extent.tile<size_of_tile, size_of_tile>(),
        [=](tiled_index<size_of_tile, size_of_tile> thid) restrict(amp)
    {
        int ti = thid.local[0];
        int tj = thid.local[1];

        for (int i = 0; i < sz; i += size_of_tile) {
            tile_static int Aarray[size_of_tile][size_of_tile];
            tile_static int Barray[size_of_tile][size_of_tile];
            Aarray[ti][tj] = arrayA(thid.global[0], tj + i);
            Barray[ti][tj] = arrayB(ti + i, thid.global[1]);
            thid.barrier.wait();

            for (int k = 0; k < size_of_tile; k++) {
                arrayC(thid.global[0], thid.global[1]) += Aarray[ti][k] * Barray[k][tj];
            }

            thid.barrier.wait();
        }

    });

    arrayC.synchronize();
}


int main() {
    double time_taken;
    clock_t start, end;
    start = clock();
    fun_for_8();
    end = clock();
    time_taken = double(end - start) / double(CLOCKS_PER_SEC);
    cout << "time taken for tile 8 : " << time_taken;
    cout << endl;

    start = clock();
    fun_for_16();
    end = clock();
    time_taken = double(end - start) / double(CLOCKS_PER_SEC);
    cout << "time taken for tile 16 : " << time_taken;
    cout << endl;

    start = clock();
    fun_for_32();
    end = clock();
    time_taken = double(end - start) / double(CLOCKS_PER_SEC);
    cout << "time taken for tile 32 : " << time_taken;


}
