To run all the above programs in command prompt:

python3 <filename> (or use python <filename> )