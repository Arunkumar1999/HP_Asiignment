import java.util.*; 

class BankAccount {
   Queue<Integer> Q = new LinkedList<Integer>();
   public BankAccount(Queue bal) { Q = bal; }
   }
   

class Producer extends Thread {
   private BankAccount account;
   public Producer(BankAccount acct) { account = acct; }
   public void run() {
       Random rand = new Random();
               int rand_int1 = rand.nextInt(1000); 
System.out.println(Thread.currentThread().getName()+" added "+rand_int1+" to queue");
    account.Q.add(rand_int1);
    synchronized (account) {
    account.notify();
    }   
  
   }
}   
   

class Consumer extends Thread {
  private BankAccount account;
  public Consumer(BankAccount acct) { account = acct; }
  public void run() {
      synchronized (account) {
try {
account.wait();
} catch (InterruptedException e) {
e.printStackTrace();
}}
if (!account.Q.isEmpty()) {
Integer integer = account.Q.poll();
System.out.println("[" + Thread.currentThread().getName() + "]: " + integer);
}
  }
}   
      
   
public class Main { 
    public static void main(String[] args) 
        throws IllegalStateException 
    { 
  
        // create object of Queue 
 Queue<Integer> Qu = new LinkedList<Integer>();
        BankAccount Q = new BankAccount(Qu);
        // Add numbers to end of Queue 
        
        System.out.println("SYNCHRONIZED OUTPUT ==> ");
      Thread[] sync_threads = new Thread[10];
      for(int i = 0; i < 10; i++) {
         if (i % 2 == 0) {
            sync_threads[i] = new Producer(Q);
         } else {
            sync_threads[i] = new Consumer(Q);
         }
      }
      for(int i = 0; i < 10; i++) {
         sync_threads[i].start();
      }
      for(int i = 0; i < 10; i++) {
         
            try {
            sync_threads[i].join();
         } catch(InterruptedException ie) {
               System.err.println(ie.getMessage());
                           
         }
         
      }
       
    }
} 

