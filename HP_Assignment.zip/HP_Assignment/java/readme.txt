To run the above programs:

use java compiler or any online java compiler is fine
