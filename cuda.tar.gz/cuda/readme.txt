To run the programs above:

nvcc <filename>
./a.out